@echo off
pip install selenium webdriver-manager