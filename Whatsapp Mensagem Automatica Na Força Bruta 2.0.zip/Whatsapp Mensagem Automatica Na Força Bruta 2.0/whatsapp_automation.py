import time
import re
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.common.exceptions import TimeoutException, NoSuchElementException

def ler_arquivo_mensagem():
    """Lê o arquivo mensagem.txt e extrai o número e a mensagem"""
    try:
        with open('mensagem.txt', 'r', encoding='utf-8') as arquivo:
            conteudo = arquivo.read()
            
        # Extrai o número
        numero_match = re.search(r'NÚMERO:\s*([\d]+)', conteudo, re.IGNORECASE)
        if not numero_match:
            raise ValueError("Número não encontrado no arquivo. Use o formato: NÚMERO: 5511999999999")
        numero = numero_match.group(1)
        
        # Extrai a mensagem
        mensagem_match = re.search(r'MENSAGEM:\s*(.+)', conteudo, re.IGNORECASE)
        if not mensagem_match:
            raise ValueError("Mensagem não encontrada no arquivo. Use o formato: MENSAGEM: Sua mensagem aqui")
        mensagem = mensagem_match.group(1).strip()
        
        return numero, mensagem
        
    except FileNotFoundError:
        print("❌ Arquivo mensagem.txt não encontrado!")
        print("Crie o arquivo com o formato:")
        print("NÚMERO: 5511999999999")
        print("MENSAGEM: Sua mensagem aqui")
        return None, None
    except Exception as e:
        print(f"❌ Erro ao ler o arquivo: {e}")
        return None, None

def enviar_mensagem_whatsapp(numero, mensagem):
    """Envia a mensagem para o número especificado no WhatsApp Web"""
    
    # Configura o driver do Chrome
    print("🚀 Iniciando navegador Chrome...")
    options = webdriver.ChromeOptions()
    # Mantém o navegador aberto mesmo após o script terminar
    options.add_experimental_option("detach", True)
    
    try:
        driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
        driver.get("https://web.whatsapp.com")
        
        print("📱 Aguardando login - Escaneie o QR Code com seu WhatsApp")
        print("⏳ Esperando o login ser concluído...")
        
        # Aguarda o usuário escanear o QR Code
        wait = WebDriverWait(driver, 120)  # 2 minutos de timeout
        
        # Espera até que a lista de conversas seja carregada (indicando login completo)
        try:
            wait.until(EC.presence_of_element_located((By.XPATH, "//div[@data-testid='chat-list']")))
            print("✅ Login realizado com sucesso!")
        except TimeoutException:
            print("❌ Tempo limite excedido. Verifique se escaneou o QR Code corretamente.")
            print("🔒 O navegador permanecerá aberto por 10 segundos...")
            time.sleep(10)
            driver.quit()
            return
        
        print(f"📤 Enviando mensagem para o número: {numero}")
        
        # Constrói o link do WhatsApp
        # Remove espaços e caracteres especiais do número
        numero_limpo = re.sub(r'[^0-9]', '', numero)
        link = f"https://web.whatsapp.com/send?phone={numero_limpo}"
        driver.get(link)
        
        # Aguarda o carregamento da página do contato
        print("⏳ Carregando conversa...")
        time.sleep(5)
        
        # Tenta encontrar e preencher o campo de mensagem
        try:
            # Espera o campo de mensagem ficar disponível
            caixa_mensagem = WebDriverWait(driver, 30).until(
                EC.presence_of_element_located((By.XPATH, "//div[@data-testid='conversation-compose-box-input']"))
            )
            
            # Limpa o campo e digita a mensagem
            caixa_mensagem.click()
            time.sleep(0.5)
            caixa_mensagem.clear()
            caixa_mensagem.send_keys(mensagem)
            print("✏️ Mensagem digitada com sucesso!")
            
            # Aguarda um instante antes de clicar no botão
            time.sleep(1)
            
            # Procura e clica no botão de enviar
            try:
                # Tenta primeiro o botão principal de enviar
                botao_enviar = driver.find_element(By.XPATH, "//button[@data-testid='compose-btn-send']")
                botao_enviar.click()
                print("✅ Botão 'Enviar' clicado automaticamente!")
                
                # Aguarda a mensagem ser enviada
                time.sleep(2)
                
                # Verifica se a mensagem foi enviada (procura por indicadores de envio)
                try:
                    # Espera um indicador de que a mensagem foi enviada
                    time.sleep(1)
                    print("✅ Mensagem enviada com sucesso!")
                except:
                    print("⚠️ Não foi possível confirmar o envio, mas a ação foi executada.")
                    
            except NoSuchElementException:
                print("⚠️ Botão 'Enviar' não encontrado. Tentando método alternativo...")
                # Método alternativo: pressionar Enter
                from selenium.webdriver.common.keys import Keys
                caixa_mensagem.send_keys(Keys.ENTER)
                print("✅ Mensagem enviada via tecla Enter!")
            
            print("📱 O navegador permanecerá aberto por 10 segundos para visualização...")
            time.sleep(10)
            
            # Fecha o navegador
            print("🔒 Fechando navegador...")
            driver.quit()
            print("✅ Processo concluído!")
            
        except TimeoutException:
            print("❌ Campo de mensagem não encontrado. Verifique se o número está correto.")
            print("💡 Dicas:")
            print("   - Verifique se o número está no formato correto: 5511999999999")
            print("   - Confirme se este número possui WhatsApp")
            print("   - O número pode ser um contato novo? Tente iniciar uma conversa manualmente primeiro.")
            print("⏳ O navegador permanecerá aberto por 10 segundos...")
            time.sleep(10)
            driver.quit()
            
        except Exception as e:
            print(f"❌ Erro ao enviar mensagem: {e}")
            print("⏳ O navegador permanecerá aberto por 10 segundos...")
            time.sleep(10)
            driver.quit()
        
    except Exception as e:
        print(f"❌ Erro geral: {e}")
        print("Certifique-se de ter o Chrome instalado e as dependências corretas.")
        print("🔒 O navegador permanecerá aberto por 10 segundos...")
        time.sleep(10)

def main():
    """Função principal"""
    print("=" * 60)
    print("📱 AUTOMAÇÃO WHATSAPP WEB - ENVIO AUTOMÁTICO")
    print("=" * 60)
    
    # Lê o arquivo de mensagem
    numero, mensagem = ler_arquivo_mensagem()
    
    if not numero or not mensagem:
        print("❌ Não foi possível ler os dados do arquivo. Verifique o formato.")
        print("\n📝 Formato correto do arquivo mensagem.txt:")
        print("NÚMERO: 5511999999999")
        print("MENSAGEM: Sua mensagem aqui")
        return
    
    print(f"📱 Número: {numero}")
    print(f"💬 Mensagem: {mensagem[:50]}{'...' if len(mensagem) > 50 else ''}")
    print("=" * 60)
    
    # Confirmação antes de enviar
    confirmacao = input("Deseja enviar esta mensagem? (s/n): ").lower().strip()
    if confirmacao != 's':
        print("❌ Operação cancelada pelo usuário.")
        return
    
    print("\n" + "=" * 60)
    print("🚀 INICIANDO ENVIO AUTOMÁTICO...")
    print("=" * 60 + "\n")
    
    # Envia a mensagem
    enviar_mensagem_whatsapp(numero, mensagem)

if __name__ == "__main__":
    main()