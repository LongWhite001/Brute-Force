pip install selenium webdriver-manager

timeout /t 3 >nul