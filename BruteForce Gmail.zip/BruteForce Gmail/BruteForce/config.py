# Configurações do Gmail Tester

# Tempo de espera entre tentativas (segundos)
WAIT_TIME = 3

# Tempo extra após captcha detectado
CAPTCHA_WAIT = 10

# Modo debug (mostra mais informações)
DEBUG = True

# Pausa longa a cada N tentativas
PAUSE_EVERY = 5
PAUSE_DURATION = 5

# Wordlist padrão
WORDLIST_FILE = "wordlist.txt"