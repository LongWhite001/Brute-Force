import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import os
import subprocess

def enviar_mensagem_whatsapp():
    """
    Script para enviar mensagem no WhatsApp
    Tenta abrir no app, se falhar, abre no navegador
    """
    
    # Configurações
    numero_telefone = "5517484745125"  # Substitua pelo número (com código do país e DDD)
    mensagem = "Nascer pobre sim, otario ai é foda"
    
    # ====== MÉTODO 1: TENTAR ABRIR PELO APP (Windows) ======
    try:
        print("Tentando abrir WhatsApp pelo aplicativo...")
        
        if os.name == 'nt':  # Windows
            # Caminho comum do WhatsApp no Windows
            caminhos_app = [
                r"C:\Program Files\WindowsApps\WhatsAppDesktop_*",
                r"C:\Users\{}\AppData\Local\WhatsApp\WhatsApp.exe".format(os.getlogin())
            ]
            
            for caminho in caminhos_app:
                if "*" in caminho:
                    import glob
                    possiveis = glob.glob(caminho)
                    if possiveis:
                        subprocess.Popen(possiveis[0])
                        break
                elif os.path.exists(caminho):
                    subprocess.Popen(caminho)
                    break
            else:
                raise Exception("WhatsApp não encontrado no sistema")
                
        elif os.name == 'posix':  # Linux/Mac
            subprocess.Popen(["whatsapp"])  # Tentar comando padrão
            # Ou usar caminhos específicos para Linux/Mac
            
        time.sleep(3)  # Aguarda o app iniciar
        
        # Aqui você pode usar pyautogui ou outra biblioteca para interagir
        # com o app (complexo), então pulamos para o método do navegador
        
        print("App iniciado. Use pyautogui para automatizar clicks.")
        print("Continuando com o método do navegador para maior confiabilidade...")
        raise Exception("Mudando para navegador")  # Força ir para navegador
        
    except Exception as e:
        print(f"Falha ao abrir app: {e}")
        print("Tentando via navegador...")
        abrir_no_navegador(numero_telefone, mensagem)

def abrir_no_navegador(numero, mensagem):
    """
    Abre WhatsApp Web no navegador e envia mensagem
    """
    # Configurar driver (certifique-se de ter o chromedriver instalado)
    options = webdriver.ChromeOptions()
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-dev-shm-usage')
    
    # Opcional: manter o navegador aberto mesmo após o script terminar
    # options.add_experimental_option("detach", True)
    
    try:
        driver = webdriver.Chrome(options=options)
        driver.maximize_window()
        
        # URL direta para conversa com o número
        url = f"https://web.whatsapp.com/send?phone={numero}"
        driver.get(url)
        
        print("Aguardando leitura do QR Code...")
        print("Se já estiver logado, vai prosseguir automaticamente.")
        
        # Aguardar carregamento da página e QR Code ser escaneado
        wait = WebDriverWait(driver, 60)  # 60 segundos para escanear o QR
        
        # Esperar o painel de conversa carregar (indicativo de login bem-sucedido)
        try:
            # Aguarda o campo de texto aparecer
            campo_mensagem = wait.until(
                EC.presence_of_element_located((By.XPATH, '//div[@contenteditable="true"][@data-tab="10"]'))
            )
            print("Login realizado com sucesso!")
            
            # Pequena pausa para garantir que a conversa carregou
            time.sleep(2)
            
            # Digitar a mensagem
            campo_mensagem.click()
            campo_mensagem.clear()
            campo_mensagem.send_keys(mensagem)
            
            # Enviar a mensagem (Enter)
            campo_mensagem.send_keys(Keys.ENTER)
            
            print(f"Mensagem enviada para {numero}!")
            print("Mensagem: 'Olá voce esta usando o Whatsapp From Meta'")
            
            # Aguardar um pouco para ver o envio
            time.sleep(3)
            
        except TimeoutException:
            print("Timeout: Verifique se o QR Code foi escaneado corretamente.")
            print("Mantendo o navegador aberto para você escanear o QR Code.")
            input("Pressione Enter após escanear o QR Code...")
            
            # Tentar novamente após o usuário escanear
            try:
                campo_mensagem = wait.until(
                    EC.presence_of_element_located((By.XPATH, '//div[@contenteditable="true"][@data-tab="10"]'))
                )
                campo_mensagem.click()
                campo_mensagem.clear()
                campo_mensagem.send_keys(mensagem)
                campo_mensagem.send_keys(Keys.ENTER)
                print("Mensagem enviada com sucesso!")
            except:
                print("Falha ao enviar mensagem após escanear QR Code.")
        
        # Manter o navegador aberto por mais alguns segundos
        print("Aguardando 10 segundos antes de fechar...")
        time.sleep(10)
        
    except Exception as e:
        print(f"Erro no navegador: {e}")
        print("Verifique se o ChromeDriver está instalado e no PATH.")
        print("Baixe em: https://chromedriver.chromium.org/")
    
    finally:
        # Fechar o navegador (opcional)
        # driver.quit()
        print("Script finalizado. O navegador permanecerá aberto.")
        input("Pressione Enter para fechar o navegador...")
        try:
            driver.quit()
        except:
            pass

if __name__ == "__main__":
    enviar_mensagem_whatsapp()
